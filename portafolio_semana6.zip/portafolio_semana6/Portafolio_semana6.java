

package com.mycompany.portafolio_semana6;


public class Portafolio_semana6 {

    public static void main(String[] args) {
        Banco_El_Cinquito banco1 =new Banco_El_Cinquito();
        Banco_El_Cinquito banco2 =new Banco_El_Cinquito();
        
        banco1.LeerAtributos();
        banco1.MostrarAtributos();
        
        banco2.Retirar();
        banco2.Depositar();
        
        
        
    }
}
